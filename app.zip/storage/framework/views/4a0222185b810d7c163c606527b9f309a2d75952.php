

<?php $__env->startSection('content'); ?>
<div class="layout-px-spacing ">

    <div class="row layout-top-spacing ">

        <div class="col-xl-12 col-lg-12 col-sm-12  layout-spacing">

            <div class="widget-content widget-content-area br-6 ">
                <div class="d-flex justify-content-between">
                    <h3 class=""> <?php echo e($page_name); ?> </h3>
                </div>
                <div class="table-responsive mb-4 mt-4">
                    <table id="antrian" class="table table-hover" style="width:100%">
                        <thead>
                            <tr>
                                <th>Tanggal</th>
                                <th>No Antri</th>
                                <th>Pasien</th>
                                <th>User</th>
                                <th>No Hp</th>
                                <th>Catatan</th>
                                <th>Waktu</th>
                                <th>Status</th>
                                <th class="no-content"></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $data_antri; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($dt->tgl); ?></td>
                                <td><?php echo e($dt->no_antrian); ?></td>
                                <td><?php echo e($dt->pasien); ?></td>
                                <td><?php echo e($dt->user_name); ?></td>
                                <td><?php echo e($dt->no_hp); ?></td>
                                <td><?php echo e($dt->catatan); ?></td>
                                <td><?php echo e($dt->waktu_detail->dJam); ?>-<?php echo e($dt->waktu_detail->sJam); ?></td>
                                <td><?php if($dt->status==0): ?>
                                    <span class="badge badge-warning"> Menunggu </span>
                                    <?php elseif($dt->status==1): ?>
                                    <span class="badge badge-success"> Selesai </span>
                                    <?php endif; ?></td>
                                <td>
                                    <a href="antri_dokter/<?php echo e($dt->id); ?>/edit"><i data-feather="eye" class="text-warning"></i></a>
                                    <!-- <a href="#" onclick="deleteData('/antri','<?php echo e($dt->id); ?>')"><i data-feather="trash" class="text-danger"></i></a> -->
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>

                    </table>
                </div>
            </div>
        </div>

    </div>

</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\antri_aja\resources\views/pages/antri_dokter/index.blade.php ENDPATH**/ ?>