

<?php $__env->startSection('content'); ?>
<div class="layout-px-spacing">

    <div class="row layout-top-spacing">

        <div class="col-xl-12 col-lg-12 col-sm-12 user-profile layout-spacing">

            <div class="widget-content widget-content-area br-6 ">
                <div class="d-flex justify-content-between">
                    <h3 class=""> Pilih Spesialis </h3>
                    <a href="<?php echo e(url('/antri')); ?>" class="mt-2 edit-profile"> <i data-feather="home" class="text-default"> </i></a>
                </div>
                <?php $__currentLoopData = $spesialis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(url('/antri/'.$dt['id'])); ?>">
                    <div id="basic" class="col-lg-12 layout-top-spacing btn" style=" text-align: left;">
                        <div class="statbox widget box box-shadow">
                            <div class="widget-header">
                                <div class="row">
                                    <div class="col-xl-12 col-md-12 col-sm-12 col-12">
                                        <h4><?php echo e($dt->spesialis); ?></h4>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>

    </div>

</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app_user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\antri_aja\resources\views/pages/antri/list_spesialis.blade.php ENDPATH**/ ?>