

<?php $__env->startSection('content'); ?>
<div class="layout-px-spacing">

    <div class="row layout-top-spacing">

        <div class="col-xl-12 col-lg-12 col-sm-12 user-profile layout-spacing">

            <div class="widget-content widget-content-area br-6 ">
                <div class="d-flex justify-content-between">
                    <h3 class=""> Daftar Dokter <?php echo e($spesialis->spesialis); ?></h3>
                    <a href="<?php echo e(url('/antri')); ?>" class="mt-2 edit-profile"> <i data-feather="home" class="text-default"> </i></a>
                </div>
                <div class="table-responsive mb-4 mt-4">
                    <table id="zero-config" class="table table-hover" style="width:100%">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Nama</th>
                                <th>No Hp</th>
                                <th>Alamat</th>
                                <th>Pengalaman</th>
                                <th>Jadwal</th>
                                <th class="no-content"></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $dokter; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($dt->name); ?></td>
                                <td><?php echo e($dt->no_hp); ?></td>
                                <td><?php echo e($dt->alamat); ?></td>
                                <td><?php echo e($dt->pengalaman); ?> tahun</td>
                                <td>
                                    <?php if(count($dt->jadwal)>0): ?>
                                    <?php
                                    $i=0;
                                    ?>
                                    <?php $__currentLoopData = $dt->jadwal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $j): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <span class="badge badge-success badge-pills"><?php echo e(($j->hari==1)?'Senin':(($j->hari==2)?'Selasa':(($j->hari==3)?'Rabu':(($j->hari==4)?'Kamis':(($j->hari==5)?'Jumat':(($j->hari==6)?'Sabtu':'Minggu')))))); ?></span>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                    Tidak Ada Jadwal!
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <a href="/antri/waktu/<?php echo e($dt->id); ?>"><button class="btn btn-primary mb-2" <?php echo e((count($dt->jadwal)>0)?'':'disabled'); ?>>Daftar</button></a>

                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>

                    </table>
                </div>
            </div>
        </div>

    </div>

</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app_user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\antri_aja\resources\views/pages/antri/list_dokter.blade.php ENDPATH**/ ?>