

<?php $__env->startSection('content'); ?>
<div class="layout-px-spacing">
    <div class="row layout-top-spacing">
        <div class="col-xl-8 col-lg-8 col-sm-8 user-profile layout-spacing">
            <div class="widget-content widget-content-area br-6 ">
                <div class="d-flex justify-content-between">
                    <h3 class=""> <?php echo e($page_name); ?> </h3>
                    <a href="#" onclick="showModal()" class="mt-2 edit-profile"> <i data-feather="plus" class="text-defaulr"> </i></a>
                </div>
                <div class="table-responsive mb-4 mt-4">
                    <table id="zero-config" class="table table-hover" style="width:100%">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Spesialis</th>
                                <th class="no-content"></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $data_spesialis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($dt->spesialis); ?></td>
                                <td>
                                    <a href="#" onclick="showModalsEdit('<?php echo e($dt->id); ?>', '<?php echo e($dt->spesialis); ?>')"><i data-feather="edit-2" class="text-warning"></i></a>
                                    <a href="#" onclick="deleteData('/spesialis','<?php echo e($dt->id); ?>')"><i data-feather="trash" class="text-danger"></i></a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>

                    </table>
                </div>
            </div>
        </div>

    </div>

    <div class="modal fade" id="addSepesialis" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Tambah Data Spesialis</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <i data-feather="x"></i>
                    </button>
                </div>
                <form class="form-info" id="myForm" novalidate enctype="multipart/form-data" method="post" action="/spesialis" autocomplete="off">
                    <?php echo csrf_field(); ?>
                    <div class="modal-body">
                        <div class="row">
                            <div class="modal-body">

                                <div class="col-lg-12">
                                    <label> Nama Spesialis </label>
                                    <input type="text" name="spesialis" id="spesialis" class="form-control" required></input>
                                </div>
                            </div>

                        </div>
                    </div>
                    <div class="modal-footer">
                        <a href="javascript:;" class="btn btn-white" data-dismiss="modal">Close</a>
                        <button type="submit" class="btn btn-primary" id="btn-submit">Submit</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="modal fade" id="editSpesialis" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Edit Data Spesialis</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <i data-feather="x"></i>
                    </button>
                </div>
                <form class="form-info" id="editForm" novalidate enctype="multipart/form-data" method="post" action="/spesialis" autocomplete="off">
                    <?php echo method_field('PUT'); ?>
                    <?php echo csrf_field(); ?>
                    <div class="modal-body">
                        <div class="row">
                            <div class="modal-body">

                                <div class="col-lg-12">
                                    <label> Nama Spesialis </label>
                                    <input type="text" name="spesialis_edit" id="spesialis_edit" class="form-control" required></input>
                                </div>
                            </div>
                            <input type="hidden" name="id_spesialis" id="id_spesialis"></input>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <a href="javascript:;" class="btn btn-white" data-dismiss="modal">Close</a>
                        <button type="submit" class="btn btn-primary" id="btn-submit">Update</button>
                    </div>
                </form>
            </div>
        </div>
    </div>


</div>

<script>
    function showModal() {
        $('#addSepesialis').modal({
            backdrop: 'static',
            keyboard: false
        });
        // $('#spesialis').focus();
    }

    function showModalsEdit(id, spesialis) {
        document.getElementById("id_spesialis").value = id;
        document.getElementById("spesialis_edit").value = spesialis;
        document.getElementById('editForm').action = "/spesialis/" + id;
        $('#editSpesialis').modal({
            backdrop: 'static',
            keyboard: false
        });
    }
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\antri_aja\resources\views/pages/spesialis/index.blade.php ENDPATH**/ ?>