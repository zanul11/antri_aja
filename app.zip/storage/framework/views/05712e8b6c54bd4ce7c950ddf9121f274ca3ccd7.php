

<?php $__env->startSection('content'); ?>
<div class="layout-px-spacing">

    <div class="row layout-top-spacing">

        <div class="col-xl-12 col-lg-12 col-sm-12 user-profile layout-spacing">

            <div class="widget-content widget-content-area br-6 ">
                <div class="d-flex justify-content-between">
                    <h3 class=""> <?php echo e($page_name); ?> </h3>
                    <a href="<?php echo e(url('marketing/create')); ?>" class="mt-2 edit-profile"> <i data-feather="plus" class="text-defaulr"> </i></a>
                </div>
                <div class="table-responsive mb-4 mt-4">
                    <table id="zero-config" class="table table-hover" style="width:100%">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>NIK</th>
                                <th>Nama</th>
                                <th>No Hp/email</th>
                                <th>Alamat</th>
                                <th class="no-content"></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $data_marketing; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($dt->nik); ?></td>
                                <td><?php echo e($dt->name); ?></td>
                                <td><?php echo e($dt->no_hp); ?>/<?php echo e($dt->email); ?></td>
                                <td><?php echo e($dt->alamat); ?></td>
                                <td>
                                    <a href="marketing/<?php echo e($dt->id); ?>/edit"><i data-feather="edit-2" class="text-warning"></i></a>
                                    <a href="#" onclick="deleteData('/marketing','<?php echo e($dt->id); ?>')"><i data-feather="trash" class="text-danger"></i></a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>

                    </table>
                </div>
            </div>
        </div>

    </div>

</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\antri_aja\resources\views/pages/marketing/index.blade.php ENDPATH**/ ?>